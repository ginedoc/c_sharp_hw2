﻿namespace hw2
{
    partial class Menu01
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Menu01));
            this.dish1 = new System.Windows.Forms.Label();
            this.dish2 = new System.Windows.Forms.Label();
            this.dish3 = new System.Windows.Forms.Label();
            this.dish4 = new System.Windows.Forms.Label();
            this.dish5 = new System.Windows.Forms.Label();
            this.dish6 = new System.Windows.Forms.Label();
            this.chooseDish = new System.Windows.Forms.GroupBox();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.Dish = new System.Windows.Forms.GroupBox();
            this.dishPic = new System.Windows.Forms.PictureBox();
            this.notif = new System.Windows.Forms.Label();
            this.price = new System.Windows.Forms.GroupBox();
            this.Price6 = new System.Windows.Forms.Label();
            this.Price5 = new System.Windows.Forms.Label();
            this.Price4 = new System.Windows.Forms.Label();
            this.Price3 = new System.Windows.Forms.Label();
            this.Price2 = new System.Windows.Forms.Label();
            this.Price1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.total = new System.Windows.Forms.Label();
            this.confirm = new System.Windows.Forms.Button();
            this.cancel = new System.Windows.Forms.Button();
            this.chooseDish.SuspendLayout();
            this.Dish.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dishPic)).BeginInit();
            this.price.SuspendLayout();
            this.SuspendLayout();
            // 
            // dish1
            // 
            this.dish1.AutoSize = true;
            this.dish1.Location = new System.Drawing.Point(10, 8);
            this.dish1.Name = "dish1";
            this.dish1.Size = new System.Drawing.Size(41, 12);
            this.dish1.TabIndex = 0;
            this.dish1.Text = "陽春麵";
            this.dish1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.dish1_MouseMove);
            // 
            // dish2
            // 
            this.dish2.AutoSize = true;
            this.dish2.Location = new System.Drawing.Point(10, 37);
            this.dish2.Name = "dish2";
            this.dish2.Size = new System.Drawing.Size(65, 12);
            this.dish2.TabIndex = 1;
            this.dish2.Text = "榨菜肉絲麵";
            this.dish2.MouseMove += new System.Windows.Forms.MouseEventHandler(this.dish2_MouseMove);
            // 
            // dish3
            // 
            this.dish3.AutoSize = true;
            this.dish3.Location = new System.Drawing.Point(10, 66);
            this.dish3.Name = "dish3";
            this.dish3.Size = new System.Drawing.Size(53, 12);
            this.dish3.TabIndex = 2;
            this.dish3.Text = "排骨酥麵";
            this.dish3.MouseMove += new System.Windows.Forms.MouseEventHandler(this.dish3_MouseMove);
            // 
            // dish4
            // 
            this.dish4.AutoSize = true;
            this.dish4.Location = new System.Drawing.Point(10, 95);
            this.dish4.Name = "dish4";
            this.dish4.Size = new System.Drawing.Size(41, 12);
            this.dish4.TabIndex = 3;
            this.dish4.Text = "麻醬麵";
            this.dish4.MouseMove += new System.Windows.Forms.MouseEventHandler(this.dish4_MouseMove);
            // 
            // dish5
            // 
            this.dish5.AutoSize = true;
            this.dish5.Location = new System.Drawing.Point(10, 127);
            this.dish5.Name = "dish5";
            this.dish5.Size = new System.Drawing.Size(41, 12);
            this.dish5.TabIndex = 4;
            this.dish5.Text = "餛飩麵";
            this.dish5.MouseMove += new System.Windows.Forms.MouseEventHandler(this.dish5_MouseMove);
            // 
            // dish6
            // 
            this.dish6.AutoSize = true;
            this.dish6.Location = new System.Drawing.Point(9, 158);
            this.dish6.Name = "dish6";
            this.dish6.Size = new System.Drawing.Size(41, 12);
            this.dish6.TabIndex = 5;
            this.dish6.Text = "牛肉麵";
            this.dish6.MouseMove += new System.Windows.Forms.MouseEventHandler(this.dish6_MouseMove);
            // 
            // chooseDish
            // 
            this.chooseDish.Controls.Add(this.checkBox7);
            this.chooseDish.Controls.Add(this.checkBox5);
            this.chooseDish.Controls.Add(this.checkBox4);
            this.chooseDish.Controls.Add(this.checkBox3);
            this.chooseDish.Controls.Add(this.checkBox2);
            this.chooseDish.Controls.Add(this.checkBox1);
            this.chooseDish.Location = new System.Drawing.Point(137, -1);
            this.chooseDish.Name = "chooseDish";
            this.chooseDish.Size = new System.Drawing.Size(51, 176);
            this.chooseDish.TabIndex = 12;
            this.chooseDish.TabStop = false;
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.Location = new System.Drawing.Point(6, 157);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(15, 14);
            this.checkBox7.TabIndex = 18;
            this.checkBox7.UseVisualStyleBackColor = true;
            this.checkBox7.CheckedChanged += new System.EventHandler(this.checkBox7_CheckedChanged);
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Location = new System.Drawing.Point(6, 123);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(15, 14);
            this.checkBox5.TabIndex = 17;
            this.checkBox5.UseVisualStyleBackColor = true;
            this.checkBox5.CheckedChanged += new System.EventHandler(this.checkBox5_CheckedChanged);
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(6, 90);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(15, 14);
            this.checkBox4.TabIndex = 3;
            this.checkBox4.UseVisualStyleBackColor = true;
            this.checkBox4.CheckedChanged += new System.EventHandler(this.checkBox4_CheckedChanged);
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(6, 62);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(15, 14);
            this.checkBox3.TabIndex = 2;
            this.checkBox3.UseVisualStyleBackColor = true;
            this.checkBox3.CheckedChanged += new System.EventHandler(this.checkBox3_CheckedChanged);
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(6, 33);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(15, 14);
            this.checkBox2.TabIndex = 1;
            this.checkBox2.UseVisualStyleBackColor = true;
            this.checkBox2.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(6, 4);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(15, 14);
            this.checkBox1.TabIndex = 0;
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // Dish
            // 
            this.Dish.Controls.Add(this.dish6);
            this.Dish.Controls.Add(this.dish5);
            this.Dish.Controls.Add(this.dish4);
            this.Dish.Controls.Add(this.dish3);
            this.Dish.Controls.Add(this.dish2);
            this.Dish.Controls.Add(this.dish1);
            this.Dish.Location = new System.Drawing.Point(3, -1);
            this.Dish.Name = "Dish";
            this.Dish.Size = new System.Drawing.Size(125, 176);
            this.Dish.TabIndex = 13;
            this.Dish.TabStop = false;
            // 
            // dishPic
            // 
            this.dishPic.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.dishPic.Image = ((System.Drawing.Image)(resources.GetObject("dishPic.Image")));
            this.dishPic.Location = new System.Drawing.Point(265, 7);
            this.dishPic.Name = "dishPic";
            this.dishPic.Size = new System.Drawing.Size(195, 168);
            this.dishPic.TabIndex = 14;
            this.dishPic.TabStop = false;
            // 
            // notif
            // 
            this.notif.AutoSize = true;
            this.notif.Location = new System.Drawing.Point(3, 182);
            this.notif.Name = "notif";
            this.notif.Size = new System.Drawing.Size(205, 12);
            this.notif.TabIndex = 15;
            this.notif.Text = "(將游標移至菜單項目可進行圖形預覽)";
            // 
            // price
            // 
            this.price.Controls.Add(this.Price6);
            this.price.Controls.Add(this.Price5);
            this.price.Controls.Add(this.Price4);
            this.price.Controls.Add(this.Price3);
            this.price.Controls.Add(this.Price2);
            this.price.Controls.Add(this.Price1);
            this.price.Location = new System.Drawing.Point(195, -1);
            this.price.Name = "price";
            this.price.Size = new System.Drawing.Size(54, 176);
            this.price.TabIndex = 16;
            this.price.TabStop = false;
            // 
            // Price6
            // 
            this.Price6.AutoSize = true;
            this.Price6.Location = new System.Drawing.Point(15, 158);
            this.Price6.Name = "Price6";
            this.Price6.Size = new System.Drawing.Size(23, 12);
            this.Price6.TabIndex = 5;
            this.Price6.Text = "$90";
            // 
            // Price5
            // 
            this.Price5.AutoSize = true;
            this.Price5.Location = new System.Drawing.Point(15, 127);
            this.Price5.Name = "Price5";
            this.Price5.Size = new System.Drawing.Size(23, 12);
            this.Price5.TabIndex = 4;
            this.Price5.Text = "$70";
            // 
            // Price4
            // 
            this.Price4.AutoSize = true;
            this.Price4.Location = new System.Drawing.Point(15, 94);
            this.Price4.Name = "Price4";
            this.Price4.Size = new System.Drawing.Size(23, 12);
            this.Price4.TabIndex = 3;
            this.Price4.Text = "$60";
            // 
            // Price3
            // 
            this.Price3.AutoSize = true;
            this.Price3.Location = new System.Drawing.Point(15, 66);
            this.Price3.Name = "Price3";
            this.Price3.Size = new System.Drawing.Size(23, 12);
            this.Price3.TabIndex = 2;
            this.Price3.Text = "$60";
            // 
            // Price2
            // 
            this.Price2.AutoSize = true;
            this.Price2.Location = new System.Drawing.Point(15, 37);
            this.Price2.Name = "Price2";
            this.Price2.Size = new System.Drawing.Size(23, 12);
            this.Price2.TabIndex = 1;
            this.Price2.Text = "$50";
            // 
            // Price1
            // 
            this.Price1.AutoSize = true;
            this.Price1.Location = new System.Drawing.Point(15, 13);
            this.Price1.Name = "Price1";
            this.Price1.Size = new System.Drawing.Size(23, 12);
            this.Price1.TabIndex = 0;
            this.Price1.Text = "$40";
            // 
            // groupBox1
            // 
            this.groupBox1.Location = new System.Drawing.Point(232, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(8, 8);
            this.groupBox1.TabIndex = 17;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // total
            // 
            this.total.AutoSize = true;
            this.total.Location = new System.Drawing.Point(193, 260);
            this.total.Name = "total";
            this.total.Size = new System.Drawing.Size(0, 12);
            this.total.TabIndex = 18;
            // 
            // confirm
            // 
            this.confirm.Location = new System.Drawing.Point(372, 248);
            this.confirm.Name = "confirm";
            this.confirm.Size = new System.Drawing.Size(75, 23);
            this.confirm.TabIndex = 19;
            this.confirm.Text = "確定";
            this.confirm.UseVisualStyleBackColor = true;
            this.confirm.Click += new System.EventHandler(this.confirm_Click);
            // 
            // cancel
            // 
            this.cancel.Location = new System.Drawing.Point(372, 210);
            this.cancel.Name = "cancel";
            this.cancel.Size = new System.Drawing.Size(75, 23);
            this.cancel.TabIndex = 20;
            this.cancel.Text = "全部重來";
            this.cancel.UseVisualStyleBackColor = true;
            this.cancel.Click += new System.EventHandler(this.cancel_Click);
            // 
            // Menu01
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(484, 361);
            this.Controls.Add(this.cancel);
            this.Controls.Add(this.confirm);
            this.Controls.Add(this.total);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.price);
            this.Controls.Add(this.notif);
            this.Controls.Add(this.dishPic);
            this.Controls.Add(this.Dish);
            this.Controls.Add(this.chooseDish);
            this.Name = "Menu01";
            this.Text = "Menu01";
            this.Load += new System.EventHandler(this.Menu01_Load);
            this.chooseDish.ResumeLayout(false);
            this.chooseDish.PerformLayout();
            this.Dish.ResumeLayout(false);
            this.Dish.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dishPic)).EndInit();
            this.price.ResumeLayout(false);
            this.price.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label dish1;
        private System.Windows.Forms.Label dish2;
        private System.Windows.Forms.Label dish3;
        private System.Windows.Forms.Label dish4;
        private System.Windows.Forms.Label dish5;
        private System.Windows.Forms.Label dish6;
        private System.Windows.Forms.GroupBox chooseDish;
        private System.Windows.Forms.GroupBox Dish;
        private System.Windows.Forms.PictureBox dishPic;
        private System.Windows.Forms.Label notif;
        private System.Windows.Forms.GroupBox price;
        private System.Windows.Forms.Label Price1;
        private System.Windows.Forms.Label Price6;
        private System.Windows.Forms.Label Price5;
        private System.Windows.Forms.Label Price4;
        private System.Windows.Forms.Label Price3;
        private System.Windows.Forms.Label Price2;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label total;
        private System.Windows.Forms.Button confirm;
        private System.Windows.Forms.Button cancel;
    }
}