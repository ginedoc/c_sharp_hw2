﻿namespace hw2
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器
        /// 修改這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.B6_3 = new System.Windows.Forms.PictureBox();
            this.B6_2 = new System.Windows.Forms.PictureBox();
            this.B6_1 = new System.Windows.Forms.PictureBox();
            this.A5_4 = new System.Windows.Forms.PictureBox();
            this.A5_1 = new System.Windows.Forms.PictureBox();
            this.A5_3 = new System.Windows.Forms.PictureBox();
            this.A4_2 = new System.Windows.Forms.PictureBox();
            this.A5_2 = new System.Windows.Forms.PictureBox();
            this.A4_1 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.B6_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.B6_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.B6_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.A5_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.A5_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.A5_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.A4_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.A5_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.A4_1)).BeginInit();
            this.SuspendLayout();
            // 
            // B6_3
            // 
            this.B6_3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.B6_3.Location = new System.Drawing.Point(202, 134);
            this.B6_3.Name = "B6_3";
            this.B6_3.Size = new System.Drawing.Size(58, 55);
            this.B6_3.TabIndex = 17;
            this.B6_3.TabStop = false;
            this.B6_3.Click += new System.EventHandler(this.B6_3_Click);
            // 
            // B6_2
            // 
            this.B6_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.B6_2.Location = new System.Drawing.Point(202, 73);
            this.B6_2.Name = "B6_2";
            this.B6_2.Size = new System.Drawing.Size(58, 55);
            this.B6_2.TabIndex = 16;
            this.B6_2.TabStop = false;
            this.B6_2.Click += new System.EventHandler(this.B6_2_Click);
            // 
            // B6_1
            // 
            this.B6_1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.B6_1.Location = new System.Drawing.Point(202, 12);
            this.B6_1.Name = "B6_1";
            this.B6_1.Size = new System.Drawing.Size(58, 55);
            this.B6_1.TabIndex = 15;
            this.B6_1.TabStop = false;
            this.B6_1.Click += new System.EventHandler(this.B6_1_Click);
            // 
            // A5_4
            // 
            this.A5_4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.A5_4.Location = new System.Drawing.Point(88, 134);
            this.A5_4.Name = "A5_4";
            this.A5_4.Size = new System.Drawing.Size(58, 55);
            this.A5_4.TabIndex = 14;
            this.A5_4.TabStop = false;
            this.A5_4.Click += new System.EventHandler(this.A5_4_Click);
            // 
            // A5_1
            // 
            this.A5_1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.A5_1.Location = new System.Drawing.Point(24, 134);
            this.A5_1.Name = "A5_1";
            this.A5_1.Size = new System.Drawing.Size(58, 55);
            this.A5_1.TabIndex = 13;
            this.A5_1.TabStop = false;
            this.A5_1.Click += new System.EventHandler(this.A5_1_Click);
            // 
            // A5_3
            // 
            this.A5_3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.A5_3.Location = new System.Drawing.Point(88, 73);
            this.A5_3.Name = "A5_3";
            this.A5_3.Size = new System.Drawing.Size(58, 55);
            this.A5_3.TabIndex = 12;
            this.A5_3.TabStop = false;
            this.A5_3.Click += new System.EventHandler(this.A5_3_Click);
            // 
            // A4_2
            // 
            this.A4_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.A4_2.Location = new System.Drawing.Point(24, 73);
            this.A4_2.Name = "A4_2";
            this.A4_2.Size = new System.Drawing.Size(58, 55);
            this.A4_2.TabIndex = 11;
            this.A4_2.TabStop = false;
            this.A4_2.Click += new System.EventHandler(this.A4_2_Click);
            // 
            // A5_2
            // 
            this.A5_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.A5_2.Location = new System.Drawing.Point(88, 12);
            this.A5_2.Name = "A5_2";
            this.A5_2.Size = new System.Drawing.Size(58, 55);
            this.A5_2.TabIndex = 10;
            this.A5_2.TabStop = false;
            this.A5_2.Click += new System.EventHandler(this.A5_2_Click);
            // 
            // A4_1
            // 
            this.A4_1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.A4_1.Location = new System.Drawing.Point(24, 12);
            this.A4_1.Name = "A4_1";
            this.A4_1.Size = new System.Drawing.Size(58, 55);
            this.A4_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.A4_1.TabIndex = 9;
            this.A4_1.TabStop = false;
            this.A4_1.Click += new System.EventHandler(this.A4_1_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(33, 222);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 18;
            this.button1.Text = " 送餐";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(114, 222);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 19;
            this.button2.Text = "清理";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(57, 192);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 12);
            this.label1.TabIndex = 20;
            this.label1.Text = "點選桌子以選擇";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(31, 30);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(11, 12);
            this.label2.TabIndex = 21;
            this.label2.Text = "4";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(31, 95);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(11, 12);
            this.label3.TabIndex = 22;
            this.label3.Text = "4";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(31, 151);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(11, 12);
            this.label4.TabIndex = 23;
            this.label4.Text = "5";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(97, 30);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(11, 12);
            this.label5.TabIndex = 24;
            this.label5.Text = "5";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(97, 151);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(11, 12);
            this.label6.TabIndex = 25;
            this.label6.Text = "5";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(97, 95);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(11, 12);
            this.label7.TabIndex = 26;
            this.label7.Text = "5";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(210, 30);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(11, 12);
            this.label8.TabIndex = 27;
            this.label8.Text = "6";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(210, 151);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(11, 12);
            this.label9.TabIndex = 28;
            this.label9.Text = "6";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(210, 95);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(11, 12);
            this.label10.TabIndex = 29;
            this.label10.Text = "6";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.B6_3);
            this.Controls.Add(this.B6_2);
            this.Controls.Add(this.B6_1);
            this.Controls.Add(this.A5_4);
            this.Controls.Add(this.A5_1);
            this.Controls.Add(this.A5_3);
            this.Controls.Add(this.A4_2);
            this.Controls.Add(this.A5_2);
            this.Controls.Add(this.A4_1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.B6_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.B6_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.B6_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.A5_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.A5_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.A5_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.A4_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.A5_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.A4_1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox B6_3;
        private System.Windows.Forms.PictureBox B6_2;
        private System.Windows.Forms.PictureBox B6_1;
        private System.Windows.Forms.PictureBox A5_4;
        private System.Windows.Forms.PictureBox A5_1;
        private System.Windows.Forms.PictureBox A5_3;
        private System.Windows.Forms.PictureBox A4_2;
        private System.Windows.Forms.PictureBox A5_2;
        private System.Windows.Forms.PictureBox A4_1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
    }
}

